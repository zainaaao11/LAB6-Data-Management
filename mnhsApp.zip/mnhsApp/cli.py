import argparse
from list_patients import list_patients_ordered_by_last_name
from schedule_appointment import schedule_appointment
from staff_share import get_staff_share
from low_stock import low_stock

def main():
    parser = argparse.ArgumentParser(description="MNHS CLI")

    sub = parser.add_subparsers(dest="cmd",required=True)

    sub.add_parser("list_patients")

    appt = sub.add_parser("schedule_appt")
    appt.add_argument("--caid",type=int,required=True)
    appt.add_argument("--iid",type=int,required=True)
    appt.add_argument("--staff",type=int,required=True)
    appt.add_argument("--dep",type=int,required=True)
    appt.add_argument("--date",required=True)
    appt.add_argument("--time",required=True)
    appt.add_argument("--reason",required=True)

    sub.add_parser('low_stock')
    sub.add_parser('staff_share')

    args = parser.parse_args()

    if args.cmd=="list_patients":
        for p in list_patients_ordered_by_last_name():
            print(p['IID'],p['FullName'])

    elif args.cmd=="schedule_appt":
        schedule_appointment(args.caid,args.iid,args.staff,args.dep,
                             args.date,args.time,args.reason)
    
    elif args.cmd == "low_stock":
        low_stock()  

    elif args.cmd == "staff_share":
        results = get_staff_share()
        if not results:
            print("\n No staff or appointment data found")
            print("Make sure you have:")
            print("  - Staff records in Staff table")
            print("  - Clinical activities in ClinicalActivity table")
            print("  - Departments linked to Hospitals\n")
        else:
            # Print header
            print(f"\n{'Staff ID':<12} {'Name':<30} {'Hospital':<25} {'Appts':<8} {'Total':<8} {'Share %':<10}")
            print("-" * 100)
            
            # Print results grouped by hospital
            current_hospital = None
            for row in results:
                # Add separator between hospitals
                if current_hospital != row['HospitalName']:
                    if current_hospital is not None:
                        print("-" * 100)
                    current_hospital = row['HospitalName']
                
                # Print row
                print(f"{row['STAFF_ID']:<12} {row['StaffName']:<30} "
                      f"{row['HospitalName']:<25} {row['TotalAppointments']:<8} "
                      f"{row['HospitalTotal']:<8} {row['PercentageShare']:<10.2f}%")
            
            print(f"\nTotal: {len(results)} staff members with appointments\n")

if __name__=="__main__":
    main()