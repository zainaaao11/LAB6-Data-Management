from db_connection import get_connection
def low_stock():
    sql="""
    SELECT M.Name, S.HID, S.Qty, S.ReorderLevel
    FROM Medication M
    LEFT JOIN 
    Stock S 
    ON S.MID=M.MID
    WHERE S.Qty < S.ReorderLevel OR S.MID IS NULL;
    """
    with get_connection() as cnx:
        with cnx.cursor(dictionary=True) as cur:
            cur.execute(sql)
            return cur.fetchall()
    
 

