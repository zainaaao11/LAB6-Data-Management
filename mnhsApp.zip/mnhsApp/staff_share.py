from db_connection import get_connection
def get_staff_share():
    """
    Command 4: Calculate appointment percentage per staff within their hospital
    Groups by hospital based on ClinicalActivity assignments
    """
    sql = """
    SELECT 
        S.STAFF_ID,
        S.FullName AS StaffName,
        H.Name AS HospitalName,
        COUNT(CA.CAID) AS TotalAppointments,
        (SELECT COUNT(CA2.CAID) 
         FROM ClinicalActivity CA2 
         JOIN Department D2 ON CA2.DEP_ID = D2.DEP_ID 
         WHERE D2.HID = H.HID
        ) AS HospitalTotal,
        ROUND(
            (COUNT(CA.CAID) * 100.0 / 
                (SELECT COUNT(CA2.CAID) 
                 FROM ClinicalActivity CA2 
                 JOIN Department D2 ON CA2.DEP_ID = D2.DEP_ID 
                 WHERE D2.HID = H.HID)
            ), 2
        ) AS PercentageShare
    FROM Staff S
    JOIN ClinicalActivity CA ON S.STAFF_ID = CA.STAFF_ID
    JOIN Department D ON CA.DEP_ID = D.DEP_ID
    JOIN Hospital H ON D.HID = H.HID
    GROUP BY S.STAFF_ID, S.FullName, H.HID, H.Name
    HAVING TotalAppointments > 0
    ORDER BY H.Name, TotalAppointments DESC
    """
    
    with get_connection() as cnx:
        with cnx.cursor(dictionary=True) as cur:
            cur.execute(sql)
            return cur.fetchall()
