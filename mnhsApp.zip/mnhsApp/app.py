from flask import Flask, render_template, request, redirect, url_for, flash
from list_patients import list_patients_ordered_by_last_name
from schedule_appointment import schedule_appointment
from low_stock import low_stock
from staff_share import get_staff_share

app = Flask(__name__)
app.secret_key = "random"


@app.route("/")
def home():
    return render_template("base.html")


@app.route("/patients")
def patients():
    patients = list_patients_ordered_by_last_name()
    return render_template("patients.html", patients=patients)


@app.route("/schedule", methods=["GET", "POST"])
def schedule():
    if request.method == "POST":
        caid = int(request.form["caid"])
        iid = int(request.form["iid"])
        staff = int(request.form["staff"])
        dep = int(request.form["dep"])
        date = request.form["date"]
        time = request.form["time"]
        reason = request.form["reason"]

        try:
            schedule_appointment(caid, iid, staff, dep, date, time, reason)
            flash("Appointment scheduled successfully.", "success")
            return redirect(url_for("schedule"))
        except Exception as e:
            flash(f"Error scheduling appointment: {e}", "error")
            return redirect(url_for("schedule"))

    return render_template("schedule_appt.html")


@app.route("/low_stock")
def low_stock_view():
    rows = low_stock()  
    return render_template("low_stock.html", rows=rows)


@app.route("/staff_share")
def staff_share_view():
    rows = get_staff_share()
    return render_template("staff_share.html", rows=rows)


if __name__ == "__main__":
    app.run(debug=True)